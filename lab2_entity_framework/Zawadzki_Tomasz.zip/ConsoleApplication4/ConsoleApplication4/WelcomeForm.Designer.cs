﻿namespace ConsoleApplication4
{
    partial class WelcomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WelcomeForm));
            this.NewEatHereOrderButton = new System.Windows.Forms.Button();
            this.ManageProductsButton = new System.Windows.Forms.Button();
            this.NewTakeAwayOrderButton = new System.Windows.Forms.Button();
            this.NewDriveThruOrder = new System.Windows.Forms.Button();
            this.QuitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // NewEatHereOrderButton
            // 
            this.NewEatHereOrderButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NewEatHereOrderButton.Location = new System.Drawing.Point(0, 0);
            this.NewEatHereOrderButton.Name = "NewEatHereOrderButton";
            this.NewEatHereOrderButton.Size = new System.Drawing.Size(220, 200);
            this.NewEatHereOrderButton.TabIndex = 0;
            this.NewEatHereOrderButton.Text = "Na miejscu";
            this.NewEatHereOrderButton.UseVisualStyleBackColor = true;
            this.NewEatHereOrderButton.Click += new System.EventHandler(this.NewEatHereOrderButton_Click);
            // 
            // ManageProductsButton
            // 
            this.ManageProductsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ManageProductsButton.Location = new System.Drawing.Point(0, 200);
            this.ManageProductsButton.Name = "ManageProductsButton";
            this.ManageProductsButton.Size = new System.Drawing.Size(330, 68);
            this.ManageProductsButton.TabIndex = 1;
            this.ManageProductsButton.Text = "Zarządzaj produktami";
            this.ManageProductsButton.UseVisualStyleBackColor = true;
            this.ManageProductsButton.Click += new System.EventHandler(this.ManageProductsButton_Click);
            // 
            // NewTakeAwayOrderButton
            // 
            this.NewTakeAwayOrderButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NewTakeAwayOrderButton.Location = new System.Drawing.Point(220, 0);
            this.NewTakeAwayOrderButton.Name = "NewTakeAwayOrderButton";
            this.NewTakeAwayOrderButton.Size = new System.Drawing.Size(220, 200);
            this.NewTakeAwayOrderButton.TabIndex = 2;
            this.NewTakeAwayOrderButton.Text = "Na wynos";
            this.NewTakeAwayOrderButton.UseVisualStyleBackColor = true;
            this.NewTakeAwayOrderButton.Click += new System.EventHandler(this.NewTakeAwayOrderButton_Click);
            // 
            // NewDriveThruOrder
            // 
            this.NewDriveThruOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NewDriveThruOrder.Location = new System.Drawing.Point(440, 0);
            this.NewDriveThruOrder.Name = "NewDriveThruOrder";
            this.NewDriveThruOrder.Size = new System.Drawing.Size(220, 200);
            this.NewDriveThruOrder.TabIndex = 3;
            this.NewDriveThruOrder.Text = "McDrive";
            this.NewDriveThruOrder.UseVisualStyleBackColor = true;
            this.NewDriveThruOrder.Click += new System.EventHandler(this.NewDriveThruOrder_Click);
            // 
            // QuitButton
            // 
            this.QuitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.QuitButton.Location = new System.Drawing.Point(330, 200);
            this.QuitButton.Name = "QuitButton";
            this.QuitButton.Size = new System.Drawing.Size(330, 68);
            this.QuitButton.TabIndex = 4;
            this.QuitButton.Text = "Wyjście";
            this.QuitButton.UseVisualStyleBackColor = true;
            this.QuitButton.Click += new System.EventHandler(this.QuitButton_Click);
            // 
            // WelcomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 268);
            this.Controls.Add(this.QuitButton);
            this.Controls.Add(this.NewDriveThruOrder);
            this.Controls.Add(this.NewTakeAwayOrderButton);
            this.Controls.Add(this.ManageProductsButton);
            this.Controls.Add(this.NewEatHereOrderButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "WelcomeForm";
            this.Text = "Witamy w McDonald\'s!";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button NewEatHereOrderButton;
        private System.Windows.Forms.Button ManageProductsButton;
        private System.Windows.Forms.Button NewTakeAwayOrderButton;
        private System.Windows.Forms.Button NewDriveThruOrder;
        private System.Windows.Forms.Button QuitButton;
    }
}