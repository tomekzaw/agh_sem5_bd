﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace ConsoleApplication4
{
    public partial class Form1 : Form
    {
        private ProdContext db;

        public Form1(ProdContext db)
        {
            InitializeComponent();
            this.db = db;
            db.Categories.Load();
            db.Products.Load();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.categoryBindingSource.DataSource = db.Categories.Local.ToBindingList();
        }

        private void categoryBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            while (true)
            {
                try
                {
                    this.db.SaveChanges();
                    break;
                }
                catch (Exception)
                {
                    MessageBox.Show("Błąd zapisu", "Wystąpił błąd przy zapisywaniu", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }
    }
}
