﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConsoleApplication4
{
    public partial class OrderForm : Form
    {
        private ProdContext db;
        private Order Order;

        private int currentNumberOfUnits = 1;
        private bool isOrderEmpty = true;
        private decimal TotalPrice = 0;

        private int buttonWidth = 130, buttonHeight = 100;
        private int numberOfButtonColumns = 8;

        public OrderForm(ProdContext db, Order order)
        {
            this.db = db;
            this.Order = order;
            InitializeComponent();
        }

        private void OrderForm_Load(object sender, EventArgs e)
        {
            this.DetailsDataGridView.Top = 0;
            this.DetailsDataGridView.Left = 0;
            this.DetailsDataGridView.Width = (numberOfButtonColumns - 1) * this.buttonWidth;
            this.DetailsDataGridView.Height = 3 * this.buttonHeight;

            for (int i = 1; i <= this.numberOfButtonColumns; ++i)
            {
                EventHandler handler = (s, _) => {
                    this.currentNumberOfUnits = Int32.Parse(((Button) s).Text);
                };
                Button button = new Button();
                button.Click += handler;
                button.Text = i.ToString();
                button.Font = new Font(button.Font.FontFamily, 24);
                button.BackColor = Color.Gray;
                button.ForeColor = Color.White;
                button.Top = this.DetailsDataGridView.Height;
                button.Left = (i - 1) * this.buttonWidth;
                button.Width = this.buttonWidth;
                button.Height = this.buttonHeight;
                this.Controls.Add(button);
            }

            int x = 0, y = 1;
            var products = this.db.Products.Include("Category").OrderBy(p => p.ButtonOrder);
            foreach (var product in products)
            {
                Button button = new Button();
                EventHandler handler = (_, __) =>
                {
                    this.AddProduct(product, this.currentNumberOfUnits);
                    this.currentNumberOfUnits = 1;
                    this.RefreshDetailsList();
                };
                button.Click += handler;
                button.Text = product.Name + "\n(" + Util.FormatPrice(product.Unitprice) + ")";
                button.Font = new Font(button.Font.FontFamily, 12);
                button.BackColor = System.Drawing.ColorTranslator.FromHtml(product.ButtonColor ?? "red");
                button.ForeColor = (button.BackColor.GetBrightness() > 0.5) ? Color.Black : Color.White;
                button.Top = this.DetailsDataGridView.Height + y * this.buttonHeight;
                button.Left = x * this.buttonWidth;
                button.Width = this.buttonWidth;
                button.Height = this.buttonHeight;
                this.Controls.Add(button);

                ++x;
                if (x >= this.numberOfButtonColumns)
                {
                    x = 0;
                    ++y;
                }
            }

            this.Width = this.numberOfButtonColumns * this.buttonWidth + 18;
            this.Height = this.DetailsDataGridView.Height + (y + (x > 0 ? 1 : 0)) * this.buttonHeight + 47;

            this.SubmitOrderButton.Top = 0;
            this.SubmitOrderButton.Left = (numberOfButtonColumns - 1) * this.buttonWidth;
            this.SubmitOrderButton.Width = this.buttonWidth;
            this.SubmitOrderButton.Height = this.buttonHeight;

            this.DeleteDetailButton.Top = this.buttonHeight;
            this.DeleteDetailButton.Left = (numberOfButtonColumns - 1) * this.buttonWidth;
            this.DeleteDetailButton.Width = this.buttonWidth;
            this.DeleteDetailButton.Height = this.buttonHeight;

            this.CancelOrderButton.Top = 2 * this.buttonHeight;
            this.CancelOrderButton.Left = (numberOfButtonColumns - 1) * this.buttonWidth;
            this.CancelOrderButton.Width = this.buttonWidth;
            this.CancelOrderButton.Height = this.buttonHeight;

            this.RefreshDetailsList();
        }

        private void AddProduct(Product product, int units) {
            if (product.UnitsInStock < units)
            {
                MessageBox.Show(
                    "Niewystarczająca liczba sztuk na stanie!",
                    "Wystąpił błąd", MessageBoxButtons.OK, MessageBoxIcon.Error
                );
                return;
            }
            product.UnitsInStock -= units;

            try
            {
                var detail = this.db.OrderDetails.Where(
                    d => d.OrderID == this.Order.OrderID &&
                    d.ProductID == product.ProductID
                ).First();
                detail.NumberOfUnits += units;
            }
            catch (InvalidOperationException)
            {
                var newDetail = new OrderDetail
                {
                    OrderID = this.Order.OrderID,
                    ProductID = product.ProductID,
                    Unitprice = product.Unitprice,
                    NumberOfUnits = units
                };
                db.OrderDetails.Add(newDetail);
            }
            finally
            {
                this.db.SaveChanges();
            }
        }

        private void RefreshDetailsList()
        {
            this.DetailsDataGridView.Rows.Clear();
            using (var db = new ProdContext())
            {
                var details = db.OrderDetails.Include("Product")
                    .Where(d => d.OrderID == this.Order.OrderID);
                this.TotalPrice = 0;
                foreach (var detail in details)
                {
                    int rowId = this.DetailsDataGridView.Rows.Add();
                    DataGridViewRow row = this.DetailsDataGridView.Rows[rowId];
                    row.Cells["ProductID"].Value = detail.ProductID;
                    row.Cells["ProductName"].Value = detail.Product.Name;
                    row.Cells["Unitprice"].Value = Util.FormatPrice(detail.Unitprice);
                    row.Cells["NumberOfUnits"].Value = detail.NumberOfUnits + " szt.";
                    decimal detailSum = detail.Unitprice * detail.NumberOfUnits;
                    this.TotalPrice += detailSum;
                    row.Cells["Sumprice"].Value = Util.FormatPrice(detailSum);
                }

                this.isOrderEmpty = (details.Count() == 0);

                this.SubmitOrderButton.Enabled = !this.isOrderEmpty;
                this.DeleteDetailButton.Enabled = !this.isOrderEmpty;

                if (!this.isOrderEmpty)
                {
                    int rowId = this.DetailsDataGridView.Rows.Add();
                    DataGridViewRow row = this.DetailsDataGridView.Rows[rowId];
                    row.Cells["Sumprice"].Value = "Σ=" + Util.FormatPrice(this.TotalPrice);
                }
            }
        }

        private void DeleteDetailButton_Click_1(object sender, EventArgs e)
        {
            foreach (DataGridViewCell cell in this.DetailsDataGridView.SelectedCells)
            {
                if (cell.OwningRow.Cells["ProductID"].Value != null)
                {
                    int productId = Int32.Parse(cell.OwningRow.Cells["ProductID"].Value.ToString());
                    OrderDetail detail =
                         (from d in db.OrderDetails
                         where d.OrderID == this.Order.OrderID && d.ProductID == productId
                         select d).FirstOrDefault();
                    if (detail != null)
                    {
                        detail.Product.UnitsInStock += detail.NumberOfUnits;
                        this.db.OrderDetails.Remove(detail);
                    }
                }
            }
            this.db.SaveChanges();
            this.RefreshDetailsList();
        }

        private void SubmitOrderButton_Click(object sender, EventArgs e)
        {
            if (this.isOrderEmpty)
            {
                return;
            }

            this.Order.Status = OrderStatus.Submitted;
            this.db.SaveChanges();
            this.Close();
            MessageBox.Show(
                "Zamówienie zostało złożone!\n" +
                "Numer Twojego zamówienia to " + this.Order.GetOrderNumber() + "\n" + 
                "Kwota do zapłaty: " + Util.FormatPrice(this.TotalPrice),
                "Złóż zamówienie", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void CancelOrderButton_Click(object sender, EventArgs e)
        {
            if (this.isOrderEmpty)
            {
                this.Close();
                return;
            }

            DialogResult answer = MessageBox.Show(
                "Czy na pewno chcesz anulować to zamówienie?",
                "Anuluj zamówienie", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.No)
            {
                return;
            }

            this.DetailsDataGridView.Rows.Clear();
            this.Order.Status = OrderStatus.Cancelled;
            foreach (var detail in this.Order.Details)
            {
                detail.Product.UnitsInStock += detail.NumberOfUnits;
            }
            this.db.SaveChanges();
            this.Close();
            MessageBox.Show(
                "Zamówienie zostało anulowane.",
                "Anuluj zamówienie", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
