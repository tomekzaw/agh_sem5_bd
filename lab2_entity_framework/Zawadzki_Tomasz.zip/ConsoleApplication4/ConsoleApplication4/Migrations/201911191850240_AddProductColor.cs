namespace ConsoleApplication4.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddProductColor : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Products", "ButtonColor", c => c.String(maxLength: 32));
            AddColumn("dbo.Products", "ButtonOrder", c => c.Int(nullable: false));
            DropColumn("dbo.Categories", "HexColor");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Categories", "HexColor", c => c.String(maxLength: 32));
            DropColumn("dbo.Products", "ButtonOrder");
            DropColumn("dbo.Products", "ButtonColor");
        }
    }
}
