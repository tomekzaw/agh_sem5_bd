namespace ConsoleApplication4.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddOrderDetailID : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.OrderDetails", "OrderDetailID", c => c.Int(nullable: false, identity: true));
            DropPrimaryKey("dbo.OrderDetails", new[] { "OrderID", "ProductID" });
            AddPrimaryKey("dbo.OrderDetails", "OrderDetailID");
        }
        
        public override void Down()
        {
            DropPrimaryKey("dbo.OrderDetails", new[] { "OrderDetailID" });
            AddPrimaryKey("dbo.OrderDetails", new[] { "OrderID", "ProductID" });
            DropColumn("dbo.OrderDetails", "OrderDetailID");
        }
    }
}
