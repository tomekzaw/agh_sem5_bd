﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConsoleApplication4
{
    public partial class WelcomeForm : Form
    {
        private ProdContext db;

        public WelcomeForm(ProdContext db)
        {
            this.db = db;
            InitializeComponent();
        }

        private void ManageProductsButton_Click(object sender, EventArgs e)
        {
            var form = new Form1(this.db);
            form.ShowDialog();
        }

        private void QuitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void NewOrder(OrderType type)
        {
            var order = new Order { Type = type };
            db.Orders.Add(order);
            db.SaveChanges();
            var form = new OrderForm(this.db, order);
            form.ShowDialog();
        }

        private void NewEatHereOrderButton_Click(object sender, EventArgs e)
        {
            this.NewOrder(OrderType.EatHere);
        }

        private void NewTakeAwayOrderButton_Click(object sender, EventArgs e)
        {
            this.NewOrder(OrderType.TakeAway);
        }

        private void NewDriveThruOrder_Click(object sender, EventArgs e)
        {
            this.NewOrder(OrderType.DriveThru);
        }
    }
}
