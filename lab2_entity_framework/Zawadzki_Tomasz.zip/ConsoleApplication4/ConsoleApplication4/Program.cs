﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Objects;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ConsoleApplication4
{
    public class Program
    {
        /*
        static void Main(string[] args)
        {
            using (var db = new ProdContext())
            {
                Console.Write("Podaj nazwę kategorii: ");
                var name = Console.ReadLine();
                if (name != "")
                {

                    var category = new Category { Name = name };
                    db.Categories.Add(category);
                    db.SaveChanges();

                    var query = from c in db.Categories
                                orderby c.Name descending
                                select c;

                    foreach (var item in query)
                    {
                        Console.WriteLine(item.Name);
                    }

                    Console.WriteLine("Press any key to exit...");
                    Console.ReadKey();
                }

                Form1 form1 = new Form1(db);
                form1.ShowDialog();
            }
        }
        */

        /*
        static void Main(string[] args)
        {
            using (var db = new ProdContext())
            {
                ShowCategories(db);
                Console.ReadKey();
            }
        }

        private static void ShowCategories(ProdContext db)
        {
            IQueryable<String> categoriesNamesQuery = db.Categories.Select(c => c.Name);
            foreach (var name in categoriesNamesQuery)
            {
                Console.WriteLine(name);
            }
        }
        */

        /*
        static void Main(string[] args)
        {
            using (var db = new ProdContext())
            {
                ShowCategoriesProducts_Join_QuerySyntax(db);
                ShowCategoriesProducts_Join_MethodSyntax(db);
                ShowCategoriesProducts_NavigationProperty_LazyLoading_QuerySyntax(db);
                ShowCategoriesProducts_NavigationProperty_LazyLoading_MethodSyntax(db);
                ShowCategoriesProducts_NavigationProperty_EagerLoading_QuerySyntax(db);
                ShowCategoriesProducts_NavigationProperty_EagerLoading_MethodSyntax(db);
                Console.ReadKey();
            }
        }

        private static void ShowCategoriesProducts_Join_QuerySyntax(ProdContext db)
        {
            var query = from category in db.Categories
                        join product in db.Products
                        on category.CategoryID equals product.CategoryID
                        select new
                        {
                            Category = category,
                            Product = product
                        };

            foreach (var row in query) {
                Console.WriteLine("{0} ({1})", row.Product.Name, row.Category.Name);
            }
        }

        private static void ShowCategoriesProducts_Join_MethodSyntax(ProdContext db)
        {
            var query = db.Categories.Join(
                db.Products,
                product => product.CategoryID,
                category => category.CategoryID,
                (category, product) => new
                {
                    Category = category,
                    Product = product
                });

            foreach (var row in query)
            {
                Console.WriteLine("{0} ({1})", row.Product.Name, row.Category.Name);
            }
        }

        private static void ShowCategoriesProducts_NavigationProperty_LazyLoading_QuerySyntax(ProdContext db)
        {
            var categoriesQuery = from category in db.Categories select category;
            foreach (var category in categoriesQuery)
            {
                foreach (var product in category.Products)
                {
                    Console.WriteLine("{0} ({1})", product.Name, category.Name);
                }
            }
        }

        private static void ShowCategoriesProducts_NavigationProperty_LazyLoading_MethodSyntax(ProdContext db)
        {
            foreach (var category in db.Categories)
            {
                foreach (var product in category.Products)
                {
                    Console.WriteLine("{0} ({1})", product.Name, category.Name);
                }
            }
        }

        private static void ShowCategoriesProducts_NavigationProperty_EagerLoading_QuerySyntax(ProdContext db)
        {
            var categoriesQuery = from category in db.Categories
                                  select new
                                  {
                                      Category = category,
                                      Products = category.Products
                                  };
            foreach (var category in categoriesQuery)
            {
                foreach (var product in category.Products)
                {
                    Console.WriteLine("{0} ({1})", product.Name, category.Category.Name);
                }
            }
        }

        private static void ShowCategoriesProducts_NavigationProperty_EagerLoading_MethodSyntax(ProdContext db)
        {
            var categoriesQuery = db.Categories.Include(c => c.Products);
            foreach (var category in categoriesQuery)
            {
                foreach (var product in category.Products)
                {
                    Console.WriteLine("{0} ({1})", product.Name, category.Name);
                }
            }
        }
        */

        /*
        static void Main(string[] args)
        {
            using (var db = new ProdContext())
            {
                ShowCategoriesWithProductsCount_MethodSyntax(db);
                ShowCategoriesWithProductsCount_QuerySyntax(db);
                Console.ReadKey();
            }
        }

        private static void ShowCategoriesWithProductsCount_QuerySyntax(ProdContext db)
        {
            var query = from category in db.Categories
                        join product in db.Products
                        on category.CategoryID equals product.CategoryID
                        into productsGroup
                        select new
                        {
                            Category = category,
                            ProductsCount = productsGroup.Count()
                        };

            foreach (var row in query)
            {
                Console.WriteLine("{0} ({1})", row.Category.Name, row.ProductsCount);
            }
        }

        private static void ShowCategoriesWithProductsCount_MethodSyntax(ProdContext db)
        {
            var query = db.Categories.GroupJoin(
                db.Products,
                product => product.CategoryID,
                category => category.CategoryID,
                (category, products) => new {
                    Category = category,
                    ProductsCount = products.Count()
                });

            foreach (var row in query)
            {
                Console.WriteLine("{0} ({1})", row.Category.Name, row.ProductsCount);
            }
        }
        */


        static void Main(string[] args)
        {
            using (var db = new ProdContext())
            {
                WelcomeForm form = new WelcomeForm(db);
                form.ShowDialog();
            }
        }
    }

    public class Category
    {
        public int CategoryID { get; set; }
        public string Name { get; set; }

        public string Description { get; set; }
        public virtual List<Product> Products { get; set; }
    }

    public class Product
    {
        public int ProductID { get; set; }
        public string Name { get; set; }
        public int UnitsInStock { get; set; }
        public int CategoryID { get; set; }

        [Column(TypeName = "money")]
        public decimal Unitprice { get; set; }

        [MaxLength(32)]
        public string ButtonColor { get; set; }
        public int ButtonOrder { get; set; }

        public Category Category { get; set; }
    }

    public enum OrderType
    {
        EatHere,
        TakeAway,
        DriveThru,
    }   

    public enum OrderStatus
    {
        New,
        Cancelled,
        Submitted,
        Paid,
        Collected
    }     

    public class Order
    {
        public int OrderID { get; set; }
        public virtual List<OrderDetail> Details { get; set; }
        public OrderType Type { get; set; }
        public OrderStatus Status { get; set; }

        public string GetOrderNumber()
        {
            return string.Format("{0,3:D3}", this.OrderID % 100);
        }
    }

    public class OrderDetail
    {
        public int OrderDetailID { get; set; }

        public int OrderID { get; set; }
        public int ProductID { get; set; }

        [Column(TypeName = "money")]
        public decimal Unitprice { get; set; }
        // product price may change over time,
        // so let's store price from order place time

        public int NumberOfUnits { get; set; }

        public Order Order { get; set; }
        public Product Product { get; set; }

        public override string ToString()
        {
            return this.Product.Name + " x" + this.NumberOfUnits;
        }
    }

    public class Customer
    {
        [Key]
        public string CompanyName { get; set; }
        public string Description { get; set; }
    }

    public class ProdContext : DbContext
    {
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }
        public DbSet<Customer> Customers { get; set; }
    }
}
