﻿namespace ConsoleApplication4
{
    partial class OrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrderForm));
            this.DetailsDataGridView = new System.Windows.Forms.DataGridView();
            this.DeleteDetailButton = new System.Windows.Forms.Button();
            this.CancelOrderButton = new System.Windows.Forms.Button();
            this.SubmitOrderButton = new System.Windows.Forms.Button();
            this.ProductID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NumberOfUnits = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unitprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sumprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.detailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.DetailsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.detailsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // DetailsDataGridView
            // 
            this.DetailsDataGridView.AllowUserToAddRows = false;
            this.DetailsDataGridView.AllowUserToDeleteRows = false;
            this.DetailsDataGridView.AllowUserToResizeColumns = false;
            this.DetailsDataGridView.AllowUserToResizeRows = false;
            this.DetailsDataGridView.BackgroundColor = System.Drawing.SystemColors.MenuText;
            this.DetailsDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DetailsDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DetailsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DetailsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductID,
            this.NumberOfUnits,
            this.ProductName,
            this.Unitprice,
            this.Sumprice});
            this.DetailsDataGridView.Location = new System.Drawing.Point(0, 0);
            this.DetailsDataGridView.Name = "DetailsDataGridView";
            this.DetailsDataGridView.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.Black;
            this.DetailsDataGridView.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.DetailsDataGridView.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.DetailsDataGridView.RowTemplate.Height = 40;
            this.DetailsDataGridView.RowTemplate.ReadOnly = true;
            this.DetailsDataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DetailsDataGridView.Size = new System.Drawing.Size(779, 359);
            this.DetailsDataGridView.TabIndex = 4;
            // 
            // DeleteDetailButton
            // 
            this.DeleteDetailButton.BackColor = System.Drawing.Color.Gold;
            this.DeleteDetailButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.DeleteDetailButton.ForeColor = System.Drawing.Color.White;
            this.DeleteDetailButton.Location = new System.Drawing.Point(832, 101);
            this.DeleteDetailButton.Name = "DeleteDetailButton";
            this.DeleteDetailButton.Size = new System.Drawing.Size(128, 93);
            this.DeleteDetailButton.TabIndex = 5;
            this.DeleteDetailButton.Text = "Usuń pozycję";
            this.DeleteDetailButton.UseVisualStyleBackColor = false;
            this.DeleteDetailButton.Click += new System.EventHandler(this.DeleteDetailButton_Click_1);
            // 
            // CancelOrderButton
            // 
            this.CancelOrderButton.BackColor = System.Drawing.Color.Red;
            this.CancelOrderButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.CancelOrderButton.ForeColor = System.Drawing.Color.White;
            this.CancelOrderButton.Location = new System.Drawing.Point(832, 200);
            this.CancelOrderButton.Name = "CancelOrderButton";
            this.CancelOrderButton.Size = new System.Drawing.Size(128, 86);
            this.CancelOrderButton.TabIndex = 6;
            this.CancelOrderButton.Text = "Anuluj zamówienie";
            this.CancelOrderButton.UseVisualStyleBackColor = false;
            this.CancelOrderButton.Click += new System.EventHandler(this.CancelOrderButton_Click);
            // 
            // SubmitOrderButton
            // 
            this.SubmitOrderButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.SubmitOrderButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.SubmitOrderButton.ForeColor = System.Drawing.Color.White;
            this.SubmitOrderButton.Location = new System.Drawing.Point(832, 12);
            this.SubmitOrderButton.Name = "SubmitOrderButton";
            this.SubmitOrderButton.Size = new System.Drawing.Size(128, 86);
            this.SubmitOrderButton.TabIndex = 7;
            this.SubmitOrderButton.Text = "Złóż zamówienie";
            this.SubmitOrderButton.UseVisualStyleBackColor = false;
            this.SubmitOrderButton.Click += new System.EventHandler(this.SubmitOrderButton_Click);
            // 
            // ProductID
            // 
            this.ProductID.HeaderText = "";
            this.ProductID.Name = "ProductID";
            this.ProductID.Visible = false;
            // 
            // NumberOfUnits
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.NumberOfUnits.DefaultCellStyle = dataGridViewCellStyle2;
            this.NumberOfUnits.HeaderText = "Liczba";
            this.NumberOfUnits.Name = "NumberOfUnits";
            this.NumberOfUnits.ReadOnly = true;
            // 
            // ProductName
            // 
            this.ProductName.HeaderText = "Nazwa";
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.Width = 300;
            // 
            // Unitprice
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Unitprice.DefaultCellStyle = dataGridViewCellStyle3;
            this.Unitprice.HeaderText = "Cena";
            this.Unitprice.Name = "Unitprice";
            this.Unitprice.ReadOnly = true;
            this.Unitprice.Width = 180;
            // 
            // Sumprice
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Sumprice.DefaultCellStyle = dataGridViewCellStyle4;
            this.Sumprice.HeaderText = "Suma";
            this.Sumprice.Name = "Sumprice";
            this.Sumprice.ReadOnly = true;
            this.Sumprice.Width = 180;
            // 
            // detailsBindingSource
            // 
            this.detailsBindingSource.DataSource = typeof(ConsoleApplication4.OrderDetail);
            // 
            // OrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(972, 333);
            this.Controls.Add(this.SubmitOrderButton);
            this.Controls.Add(this.CancelOrderButton);
            this.Controls.Add(this.DeleteDetailButton);
            this.Controls.Add(this.DetailsDataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "OrderForm";
            this.Text = "Zamówienie";
            this.Load += new System.EventHandler(this.OrderForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DetailsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.detailsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource detailsBindingSource;
        private System.Windows.Forms.DataGridView DetailsDataGridView;
        private System.Windows.Forms.Button DeleteDetailButton;
        private System.Windows.Forms.Button CancelOrderButton;
        private System.Windows.Forms.Button SubmitOrderButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductID;
        private System.Windows.Forms.DataGridViewTextBoxColumn NumberOfUnits;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unitprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sumprice;
    }
}