insert into categories (name) values ('Burgery');
insert into categories (name) values ('Zestawy');
insert into categories (name) values ('Wrapy');
insert into categories (name) values ('Dodatki');
insert into categories (name) values ('Napoje');
insert into categories (name) values ('Dodatki');
insert into categories (name) values ('Desery');

insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Cheeseburger', 999, 1, 4.5, 'DarkOrange', 1);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Hamburger', 999, 1, 4, 'SaddleBrown', 2);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Kurczakburger', 999, 1, 5, 'ForestGreen', 3);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Big Mac', 999, 1, 9.6, 'red', 4);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('McRoyal', 999, 1, 10.5, 'DeepSkyBlue', 5);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Filet-O-Fish', 999, 1, 8.7, 'Gainsboro', 6);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Happy Meal', 999, 2, 10.5, 'Magenta', 7);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('2 for U', 999, 2, 6, 'red', 8);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('McWrap', 999, 3, 11.7, 'MediumSlateBlue', 9);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Frytki', 999, 4, 5.9, 'Gold', 10);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Frytki zakr�cone', 999, 4, 6.9, 'GoldenRod', 11);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Chrupserki', 999, 4, 7.9, 'Yellow', 12);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('McNuggets', 999, 4, 7.9, 'Purple', 13);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Coca-Cola', 999, 5, 5.9, 'red', 14);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Fanta', 999, 5, 5.9, 'Orange', 15);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Sprite', 999, 5, 5.9, 'LimeGreen', 16);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Ice Tea', 999, 5, 5.9, 'Peru', 17);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Sa�atka', 999, 6, 5.9, 'Lime', 18);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Lody z polew�', 7, 23, 6.2, 'green', 19);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('McFlurry', 7, 23, 7.2, 'blue', 20);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Ciastko jab�kowe', 7, 23, 4.5, 'OrangeRed', 21);
insert into products (name, unitsinstock, categoryid, unitprice, buttoncolor, buttonorder)
values ('Ciastko sezonowe', 7, 23, 4.5, 'Purple', 22);