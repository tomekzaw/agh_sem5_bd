﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ConsoleApplication4
{
    public class Program
    {
        static void Main(string[] args)
        {
            using (var db = new ProdContext())
            {
                Console.Write("Podaj nazwę kategorii: ");
                var name = Console.ReadLine();
                if (name != "")
                {

                    var category = new Category { Name = name };
                    db.Categories.Add(category);
                    db.SaveChanges();

                    var query = from c in db.Categories
                                orderby c.Name descending
                                select c;

                    foreach (var item in query)
                    {
                        Console.WriteLine(item.Name);
                    }

                    //Console.WriteLine("Press any key to exit...");
                    //Console.ReadKey();
                }

                Form1 form1 = new Form1(db);
                form1.ShowDialog();
            }
        }
    }

    public class Category
    {
        public int CategoryID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public virtual List<Product> Products { get; set; }
    }

    public class Product
    {
        public int ProductID { get; set; }
        public string Name { get; set; }
        public int UnitsInStock { get; set; }
        public int CategoryID { get; set; }

        [Column(TypeName = "money")]
        public decimal Unitprice { get; set; }
    }

    public class Customer
    {
        [Key]
        public string CompanyName { get; set; }
        public string Description { get; set; }
    }

    public class ProdContext : DbContext
    {
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Customer> Customers { get; set; }
    }
}
